All data contained within  
https://www.emi.ea.govt.nz/Wholesale/Datasets/Generation
