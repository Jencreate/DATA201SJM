# Title
Impact of Hydrostation power output due to river flow, on residential electricity cost

# Report

### Chosen topic
Energy production by river flow with electricity cost.

### The data sources we used
- The CSV file for river noted in river from NIWA
- Hydrostations in Canterbury
- Hydrostations and rivers in the south island
- Energy cost
- Hydrostations and energy output

### The reason why we chose these data sources
The topic we chose is "Energy production by river flow with electricity cost". We chose the hydrostations in Canterbury and the rivers in the south island because it is easier to find the relationship between the hydrostations and the river.

### Target
To find the datas about what we need and find the relationship between energy production by river flow with electricity cost.

### Difficulties


### Techniques


### Plan and failure
- "Energy production by river flow with rainfall" is the topic that we chose first. But after discussion we thought that we can't find the sufficient rain fall data over a long period of time for the locations of the hydrostations. So we changed the topic to "Energy production by river flow with electricity cost".
- 
