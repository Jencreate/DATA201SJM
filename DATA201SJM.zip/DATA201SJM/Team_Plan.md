#### Entry (01/10/21) - Team
- Find a way to webscrape the data for each subject from their sources (Due 08/10/21).
  - [x] Sujung: Quartely electricity cost in 2020
  - [x] Jensen: Hydrostations and their power production in 2020
  - [x] Matt: Rivers and their flow rate in 2020

#### Entry (08/10/21) - Team
- [x] Matt & Jensen: Relate the river flow data to the locations of the hydrostations where relevant (Due 11/10/21)
- [x] Sujung & Richard: Look at how to write the report (Due 14/10/21).

#### Entry (22/10/21) - Team
- [x] Jensen: Automate the wrangling of the data for power generation of each relevant hydrostation
- [ ] Sujung: Automate the wrangling for electricity cost data

