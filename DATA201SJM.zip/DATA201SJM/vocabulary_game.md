## Random words
### Jensen's words  
pineapple 
chocolate
space
blue
cat
robot
meat
snake
boat
fire
orange
purple
goat
cars
nuclear
university
electrical
submarine
person
lego
umbrella
pottery
green
snowflake
cleaner
population
state
koala
tent
igloo

### Sujung's Words 
christchurch
gardening
money
home
pork ribs
beer
mandarine
mac book
work
tomato
carrot
mask
barber
mall
energy
weather
cow
farm

### Matthew's Words  
Youtube 
colours 
houses 
accommodation 
Mountains
 Outdoors
 Snow
 weather 
waves 
beach 
sand 
dunes 
hills 
roads 
Cars
 Paths
 Routes
 playground 
soil 
Bark
 trees 
lighting 
Components
 keyboard 
typing 
information 
data 
centre 
cities 
countries 
planets 
systems 
physics 
music 
Patterns
 Distance
 images 
Searching
 Google
 Business
 empire 
Control
 Space
 Database
 Numbers
 Letters
 alphabet 
landscape 
products 
software 
hardware


## Word Combinations
- meat youtube mask
  - cooking videos on youtube 
- home countries fire 
  - home fires in each country compared canterbury
- electrical money cities 
  - cost of electricity in nz cities compared to canterbury
- cleaner work music 
  - percentage of music listening cleaners in canterbury
- garden cars physics 
  - car crashes in greenspaces in canterbury  
  - autonomous cars having issues with green spaces  
- purple beer patterns 
  - pattern recognition under the influence
- business population farm 
  - Business population in farm areas
- nuclear macbook components 
- landscape robot cow 
  - irrigation systems dealing with different landscapes
- pineapple sand pork 
  - Growth of plants in different soil
- university space tomato 
  - Does consumming fruits and vegetables increase work productivity at school?
- database blue mall 
  - Do blue products sell better?
- energy pottery routes 
  - comparing materials used for each road
  - Energy efficient way of extracting raw materials for pottery  
  - Most efficient road in canterbury  
- snowflake weather clothes 
  - rating for snow resistant clothes
  - Layers worn in cold weather  
  - energy production by weather  
  - energy production by river flow with rainfall <- Topic 1
  - energy production by riverflow with electricity cost <- Topic 2


### Dataset topics available on spreadsheet
- Crime
- Travel and immigration
- Death
- Prison
- GDP
- River flow 
- Energy 
- rainfall
- Air Quality

